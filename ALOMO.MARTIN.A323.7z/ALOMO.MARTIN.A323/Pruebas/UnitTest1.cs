using Entidades;

namespace Pruebas
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void GuardarXML_DeberiaSeriaListaSeriesFormatoXML()
        {

            List<Serie> lista = new List<Serie>()
            {
                new Serie("Vikingos","Guerra"),
                new Serie("Breaking Bad","Narcos"),
                new Serie("Blacks Sails","Piratas")
            };

            Serializadora serializadora = new Serializadora();

            string rutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string rutaXml = Path.Combine(rutaEscritorio, "pruebaXML.xml");



            serializadora.Guardar(lista, rutaXml);


            Assert.IsTrue(File.Exists(rutaXml));
            string contenido = File.ReadAllText(rutaXml);
            Assert.IsTrue(contenido is not null);


        }


        [TestMethod]
        public void GuardarJSON_DeberiaSeriaListaSeriesFromatoJSON()
        {
            List<Serie> lista = new List<Serie>()
            {
                new Serie("Vikingos","Guerra"),
                new Serie("Breaking Bad","Narcos"),
                new Serie("Blacks Sails","Piratas")
            };

            Serializadora serializadora = new Serializadora();

            string rutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string rutaJson = Path.Combine(rutaEscritorio, "pruebaJSON.json");


            ((IGuardar<List<Serie>>)serializadora).Guardar(lista, rutaJson);


            Assert.IsTrue(File.Exists(rutaJson));
            string contenido = File.ReadAllText(rutaJson);
            Assert.IsTrue(contenido is not null);
        }



    }
}