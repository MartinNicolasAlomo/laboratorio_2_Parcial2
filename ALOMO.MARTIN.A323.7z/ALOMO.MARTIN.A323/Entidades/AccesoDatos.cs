﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Entidades
{
    public static class AccesoDatos
    {
        static private string cadenaConexion;
        static private SqlCommand comando;
        static private SqlConnection conexion;

        static AccesoDatos()
        {
            cadenaConexion = @"Data Source=.;Initial Catalog=20240701-SP;Integrated Security=True";
            comando = new SqlCommand();
            conexion = new SqlConnection(cadenaConexion);
            comando.CommandType = System.Data.CommandType.Text;
            comando.Connection = conexion;
        }

        public static List<Serie> ObtenerBacklog()
        {
            List<Serie> listaSeries = new List<Serie>();
            try
            {
                conexion.Open();
                comando.CommandText = "SELECT * FROM series";
                using (SqlDataReader dataReader = comando.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        listaSeries.Add(new Serie(dataReader["nombre"].ToString(), dataReader["genero"].ToString()));
                    }
                }
            }
            catch (BackLogException ex)
            {
                Logger.Log(ex.Message);
                throw new BackLogException("Error al intentar obtener la lista de series.", ex);
            }
            finally
            {
                conexion.Close();
            }
            return listaSeries;
        }

        public static void ActualizarSerie(Serie item)
        {
            try
            {
                comando.Parameters.Clear();
                conexion.Open();
                comando.CommandText =
                    $"UPDATE series SET alumno = 'Martín Alomo' " +
                    $"WHERE nombre = @nombre";
                comando.Parameters.AddWithValue("@NOMBRE", item.Nombre);
                int filasAfectadas = comando.ExecuteNonQuery();
            }
            catch (BackLogException ex)
            {
                Logger.Log(ex.Message);
                throw new BackLogException("Error al intentar actualizar la serie.", ex);
            }
            finally
            {
                conexion.Close();
            }
        }



    }
}
