﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public delegate void DelegadoBackLog(Serie serie);

    public class ManejadorBackLog
    {
        public event DelegadoBackLog NuevaSerieParaVer;

        public void IniciarManejador(List<Serie> series)
        {
            Task.Run(() => MoverSeries(series));
        }

        private void MoverSeries(List<Serie> series)
        {
            while (series.Count > 0)
            {
                int index = series.GenerarRandom();
                Serie serieSeleccionada = series[index];

                try
                {
                    AccesoDatos.ActualizarSerie(serieSeleccionada);
                }
                catch (BackLogException ex)
                {
                    throw new BackLogException($"Error al intentar mover la serie {serieSeleccionada.Nombre} de lugar.", ex);
                }

                series.RemoveAt(index);

                Thread.Sleep(1500);

                if (NuevaSerieParaVer is not null)
                {
                    NuevaSerieParaVer.Invoke(serieSeleccionada);
                }
            }
        }



    }
}
