﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Logger
    {
        public static void Log(string mensaje)
        {
            string ruta = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string rutaCompleta = Path.Combine(ruta, "Log.txt");
            try
            {
                if (!Directory.Exists(ruta))
                {
                    Directory.CreateDirectory(ruta);
                }
                using (StreamWriter writer = new StreamWriter(rutaCompleta, true))
                {
                    writer.WriteLine($"{mensaje} - {DateTime.Now:HH:mm:ss}");
                }
            }
            catch (BackLogException ex)
            {
                throw new BackLogException("Error al guardar la lista de series en formato TXT.", ex);
            }
        }
    }
}
